# Monke Mod Manager
![Preview](https://i.imgur.com/6mEIBxm.png)

This program will install custom mods into Gorilla Tag automatically, and can be re-run in order to update the mods

The program currently supports

* [BepInEx](https://github.com/BepInEx/BepInEx) by **The BepInEx Team**
* [Gorilla Cosmetics](https://github.com/legoandmars/GorillaCosmetics) by **Bobbie**


This uses the github api to get the latest release of all these mods, so you know you'll always be getting the latest version!
(If you've made a mod that you want added to the installer, send me a message on Discord! `Steven 🎀#0001`)
